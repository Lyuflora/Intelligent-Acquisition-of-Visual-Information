"""
Simple augmented reality, calibrate camera with images listed in img_names,
and project sth on 5 randomly chosen input images.
Output:
	Positions of camera centers in the world coordinates.
"""
# Python 2/3 compatibility
from __future__ import print_function

import numpy as np
import cv2 as cv

import glob
import os
import random

# chessboard pattern points
pattern_size = (8, 6)
pattern_points = np.zeros((np.prod(pattern_size), 3), np.float32)
pattern_points[:, :2] = np.indices(pattern_size).T.reshape(-1, 2)

# image names
img_names = random.sample(glob.glob('lab2_1/*.jpg'), 20)

def processImage(fn):
	"""
	Process a image with chessboard

	:param str fn: file name

	:return: corners, pattern_points
	"""
	img = cv.imread(fn, 0)
	if img is None:
		print("Failed to load", fn)
		return None

	found, corners = cv.findChessboardCorners(img, pattern_size, None)
	if not found:
		print('Chessboard not found in', fn)
		return None

	return (corners.reshape(-1, 2), pattern_points)

if __name__ == '__main__':
	h, w = cv.imread(img_names[0], 0).shape[:2]

	chessboards = [processImage(fn) for fn in img_names]
	chessboards = [cb for cb in chessboards if cb is not None]

	obj_points = []
	img_points = []
	for (corners, pattern_points) in chessboards:
		img_points.append(corners)
		obj_points.append(pattern_points)

	# calibrate camera
	rms, camera_matrix, dist_coefs, rvecs, tvecs = cv.calibrateCamera(obj_points, img_points, (w, h), None, None)

	# convert rotation vectors to rotation matrices
	rmats = []
	for j in range(len(rvecs)):
		dst, _ = cv.Rodrigues(rvecs[j])
		rmats.append(dst)

	# draw box
	vtcs = np.float32([[0,0,0], [0,1,0], [1,1,0], [1,0,0],
                      [0,0,-1], [0,1,-1], [1,1,-1], [1,0,-1]])
	for j in range(5):
		img = cv.imread(img_names[j])

		pnts, jac = cv.projectPoints(vtcs, rvecs[j], tvecs[j], camera_matrix, dist_coefs)
		pnts = np.int32(pnts).reshape(-1,2)

		for k in range(len(pnts)):
			for i in range(k + 1, len(pnts)):
				cv.line(img, tuple(pnts[k]), tuple(pnts[i]), (0, 255, 0))

		cv.imshow(img_names[j], img)
		# cv.imwrite(img_names[j], img)
		cv.waitKey(0)

	cv.destroyAllWindows()
