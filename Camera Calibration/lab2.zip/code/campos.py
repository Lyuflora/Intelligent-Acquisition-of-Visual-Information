"""
Calibrate camera using images of chessboard specified by img_names
Output:
	Positions of camera centers in the world coordinates
"""
# Python 2/3 compatibility
from __future__ import print_function

import numpy as np
import cv2 as cv

import glob
import os
import random

# chessboard pattern points
pattern_size = (8, 6)
pattern_points = np.zeros((np.prod(pattern_size), 3), np.float32)
pattern_points[:, :2] = np.indices(pattern_size).T.reshape(-1, 2)

# image names
img_names = glob.glob('lab2_1/*.jpg')

def processImage(fn):
	"""
	Process a image with chessboard

	:param str fn: file name

	:return: corners, pattern_points
	"""
	img = cv.imread(fn, 0)
	if img is None:
		print("Failed to load", fn)
		return None

	found, corners = cv.findChessboardCorners(img, pattern_size, None)
	if found:
		term = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_COUNT, 30, 0.1)
		cv.cornerSubPix(img, corners, (5, 5), (-1, -1), term)
	else:
		print('Chessboard not found in', fn)
		return None

	return (corners.reshape(-1, 2), pattern_points)

if __name__ == '__main__':
	h, w = cv.imread(img_names[0], 0).shape[:2]

	chessboards = [processImage(fn) for fn in img_names]
	chessboards = [cb for cb in chessboards if cb is not None]

	sampling_list = [50]
	for i in sampling_list:
		obj_points = []
		img_points = []
		sub_chessboards = random.sample(chessboards, i)
		for (corners, pattern_points) in sub_chessboards:
			img_points.append(corners)
			obj_points.append(pattern_points)

		# calibrate camera
		rms, camera_matrix, dist_coefs, rvecs, tvecs = cv.calibrateCamera(obj_points, img_points, (w, h), None, None)

		# convert rotation vectors to rotation matrices
		rmats = []
		for j in range(len(rvecs)):
			dst, _ = cv.Rodrigues(rvecs[j])
			rmats.append(dst)

		# camera positions
		for j in range(len(rmats)):
			print(np.dot(-rmats[j].transpose(), tvecs[j]))


		# folder = './result/'
		# if not os.path.exists(folder):
		# 	os.makedirs(folder)
		# np.savetxt(folder + 'camera_matrix.txt', camera_matrix)
		# np.savetxt(folder + 'dist_coefs.txt', dist_coefs)
		# # np.savetxt(folder + 'rvec.txt', rvecs)
		# # np.savetxt(folder + 'tvec.txt', tvecs)

		# print("RMS:\n", rms)

		# print("\nINTRINSICS")
		# print("\nCamera matrix:\n", camera_matrix)
		# print("\nDistortion coefficients:\n", dist_coefs.ravel())
		
		# print("\nEXTRINSICS")
		# for j in range(len(tvecs)):
		# 	print("Rotation matrix:\n", rmats[j])
		# 	print("Translation vector:\n", tvecs[j])
